
public class TypeCasting {

	public static void main(String[] args) {
		 int intValue = 2300;
	        double doubleValue = intValue; // Implicit conversion from int to double

	        System.out.println("Implicit Type Casting (Widening):");
	        System.out.println("int value: " + intValue);
	        System.out.println("double value: " + doubleValue);

	        // Explicit Type Casting (Narrowing)
	        double doubleNum = 252.163;
	        int intNum = (int) doubleNum; // Explicit conversion from double to int

	        System.out.println("\nExplicit Type Casting (Narrowing):");
	        System.out.println("double value: " + doubleNum);
	        System.out.println("int value: " + intNum);

	}

}
